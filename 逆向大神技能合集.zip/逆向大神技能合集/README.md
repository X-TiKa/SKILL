# 逆向大神技能合集

> 逆向 / 渗透技能合集 + 无头 IDE MCP 完整资料包 · 打包时间 2026-09-14 01:59:20

## 这是什么

- **452 个技能条目**（434 个技能束 + 18 个仓库路由），技能正文合计 **53.1 MB**
- **2 个无头 IDE MCP**：Serena（源码 IDE，21 工具）+ r2mcp（二进制 IDE，29 工具）——见 `mcp/`
- **19 个上游开源仓库**的完整副本 + 1 个用户上传技能（`xiaojianbang-auto-reverse`）
- 配套环境记录与全部安装脚本（`docs/`）

## 目录结构

```text
逆向大神技能合集/
├── README.md            本文件
├── 技能清单.md / .csv    全量清单（可搜索 / 可导表格）
├── index.html           离线可搜索索引页（双击即开，无需联网）
├── 技能详情/            每技能一页：来源 / 路径 / 文件树 / 说明
├── skills/              技能束（直接放进 Agent 的 skills 目录即可用）
├── routers/             仓库路由文件（指向未注册技能的磁盘路径）
├── repos/               上游仓库完整副本（含未注册技能）
├── mcp/                 MCP 文档：Serena / r2mcp 工具清单、配置、语言服务器
└── docs/                环境记录 AGENTS.md + 全部安装脚本
```

## 分类概览

| 分类 | 条目数 |
|---|---|
| 二进制逆向 / 反编译 | 97 |
| 恶意代码 / 取证 / 情报 | 89 |
| 其他 | 54 |
| 安卓 / 移动逆向 | 50 |
| 漏洞挖掘 / 利用开发 | 33 |
| 内核 / 驱动 / 虚拟化 | 32 |
| Web / 渗透测试 | 23 |
| 工程 / 流程 / 元技能 | 23 |
| 反作弊 / 游戏逆向 | 16 |
| 反混淆 / 脱壳 / 破解 | 14 |
| CTF | 7 |
| 代码审计 / 供应链 | 7 |
| LLM / AI 安全 | 5 |
| IDAPython / IDA 工具链 | 2 |

## 安装方式

### DSH

技能根按发现规则扫描（只扫**顶层**：`<name>/SKILL.md` 或 `<name>.md`，嵌套不被发现）：

| 优先级 | 路径 |
|---|---|
| 100 | `<项目根>/.dsh/skills` |
| 200 | `<项目根>/.agents/skills` |
| 300 | 配置项 `customSkillDirs` |
| 400 | `$DSH_HOME/skills` |
| 500 | `~/.agents/skills` |

```bash
cp -a skills/*      /root/.dsh/skills/    # 技能束
cp -a routers/*.md  /root/.dsh/skills/    # 路由（可选）
```

### Claude Code / Codex / Cursor 等

```bash
cp -a skills/* ~/.claude/skills/          # Claude Code
# 或按各工具的 skills 目录约定投放
```

### MCP 接入（DSH）

DSH 自带 `@deepseek-ai/dsh-mcp-client`，在 profile 的用户补丁层 `$DSH_HOME/profiles/<profile>/cordis.patch.yml` 里加条目即可。详见 `mcp/README.md`。

### 从上游仓库重新获取（国内网络）

```bash
curl -L -o r.zip "https://gh-proxy.com/https://github.com/OWNER/REPO/archive/refs/heads/main.zip"
curl -sL "https://gh-proxy.com/https://api.github.com/repos/OWNER/REPO/releases/latest"   # 版本发现（releases.atom 会 403）
# git 也可代理（临时垫片，不写全局配置）
mkdir -p /tmp/gitshim && printf '#!/bin/sh\nexec /usr/bin/git -c url."https://gh-proxy.com/https://github.com/".insteadOf="https://github.com/" "$@"\n' > /tmp/gitshim/git && chmod +x /tmp/gitshim/git
PATH=/tmp/gitshim:$PATH git clone https://gh-proxy.com/https://github.com/OWNER/REPO
```

## 上游仓库与下载地址

| 仓库 | 说明 | 地址 |
|---|---|---|
| `rev-skills` | 122 个逆向技能，12 大类网关，入口 re-analyze；覆盖二进制/恶意代码/固件/协议/移动/反混淆/破解/漏洞/CTF/托管代码/取证/macOS/硬件/AI/SDR | https://github.com/dslsdzc/rev-skills |
| `unleash` | 216 个唯一技能（原 432 个含 go/embed 同内容副本）：反作弊 EAC/Vanguard、内核驱动、BYOVD、Hypervisor 隐形、脱壳反混淆、游戏逆向 UE/Unity/Source、注入、作弊器工程、利用开发、Windows 0day、LLM 越狱红队 | https://github.com/NetVar1337/unleash |
| `as0ler_skills` | 6 个：vmprotect 反混淆、deobfuscation、frida、r2frida、radare2、unreal5 | https://github.com/as0ler/skills |
| `CkSKILLS` | 20 个安全技能：windows-reverse-engineering、android-security-audit、miniprogram-security 等 | https://github.com/zhaji2333/CkSKILLS |
| `r00tedbrain-backup_skills` | reverse-engineering 单技能 | https://github.com/r00tedbrain-backup/skills |
| `reverse-skill` | 逆向技能路由包：44 条路由规则 + 45 个技能模块 | https://github.com/zhaoxuya520/reverse-skill |
| `reverse-skills` | P4nda0s 二进制逆向 7 件套（rev-symbol/struct/frida/unicorn/u3d/dex-dump/ios-dump） | https://github.com/P4nda0s/reverse-skills |
| `ctf-skills` | CTF 全类别 11 个技能 | https://github.com/ljagiello/ctf-skills |
| `claude-reverse-skills` | 5 件套：reverse-engineering / ida-reverse / apk-reverse / radare2 / mcp-js-reverse-playbook | https://github.com/haikow/claude-reverse-skills |
| `android-reverse-engineering-skill` | APK/XAPK/JAR/AAR 反编译 + API 提取 + 调用链 | https://github.com/SimoneAvogadro/android-reverse-engineering-skill |
| `android-reverse-engineering-claude-skill` | Codex 版 Android 逆向 | https://github.com/CreditTone/android-reverse-engineering-skill |
| `iOS-reverse-engineering-claude-skill` | iOS IPA/Mach-O 分析 | https://github.com/incogbyte/iOS-reverse-engineering-claude-skill |
| `ai-mobile-reverse-skills` | 移动安全 6 阶段总控 | https://github.com/Fausto-404/ai-mobile-reverse-skills |
| `malware-analysis-claude-skills` | 恶意代码分析 6 技能 | https://github.com/gl0bal01/malware-analysis-claude-skills |
| `skills` | Trail of Bits 83 技能（本包注册 25 个安全相关） | https://github.com/trailofbits/skills |
| `agent-skills` | magnus919 171 技能（本包注册 2 个） | https://github.com/magnus919/agent-skills |
| `SkillSpector` | NVIDIA Agent Skills 安全扫描器 | https://github.com/NVIDIA/SkillSpector |
| `Skills4RedTeam` | 红队技能索引 | https://github.com/din4e/Skills4RedTeam |
| `universal-game-modder` | 游戏修改 MCP server（引擎自动检测 + 原生二进制分析） | https://github.com/doritoman90000/universal-game-modder |
| `xiaojianbang-auto-reverse` | 小肩膀 Android Native 反检测分析与绕过工程（中文） | 用户上传（小肩膀，非公开仓库） |

## 作者信息

`xiaojianbang-auto-reverse` 作者：**小肩膀** · 微信 xiaojianbang8888 · 官网 https://xjbedu.site · B站 https://space.bilibili.com/534838862 · 公众号 非攻code

## 许可与来源

各技能版权归其原作者 / 仓库所有，许可见各仓库内 LICENSE：

- `rev-skills` — https://github.com/dslsdzc/rev-skills
- `unleash` — https://github.com/NetVar1337/unleash
- `as0ler_skills` — https://github.com/as0ler/skills
- `CkSKILLS` — https://github.com/zhaji2333/CkSKILLS
- `r00tedbrain-backup_skills` — https://github.com/r00tedbrain-backup/skills
- `reverse-skill` — https://github.com/zhaoxuya520/reverse-skill
- `reverse-skills` — https://github.com/P4nda0s/reverse-skills
- `ctf-skills` — https://github.com/ljagiello/ctf-skills
- `claude-reverse-skills` — https://github.com/haikow/claude-reverse-skills
- `android-reverse-engineering-skill` — https://github.com/SimoneAvogadro/android-reverse-engineering-skill
- `android-reverse-engineering-claude-skill` — https://github.com/CreditTone/android-reverse-engineering-skill
- `iOS-reverse-engineering-claude-skill` — https://github.com/incogbyte/iOS-reverse-engineering-claude-skill
- `ai-mobile-reverse-skills` — https://github.com/Fausto-404/ai-mobile-reverse-skills
- `malware-analysis-claude-skills` — https://github.com/gl0bal01/malware-analysis-claude-skills
- `skills` — https://github.com/trailofbits/skills
- `agent-skills` — https://github.com/magnus919/agent-skills
- `SkillSpector` — https://github.com/NVIDIA/SkillSpector
- `Skills4RedTeam` — https://github.com/din4e/Skills4RedTeam
- `universal-game-modder` — https://github.com/doritoman90000/universal-game-modder

本包仅做整理归档，未修改任何技能内容。

> **使用边界**：仅限自有或已获明确授权的样本、研究与调试环境。逆向工程的合法性因司法辖区而异，使用者须自行遵守所在地法律。