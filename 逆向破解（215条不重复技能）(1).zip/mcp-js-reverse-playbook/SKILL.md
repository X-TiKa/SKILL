---
name: mcp-js-reverse-playbook
description: 在使用 js-reverse-mcp 做前端 JavaScript 逆向时使用，适用于签名链路定位、页面观察取证、运行时采样、本地补环境复现与证据化输出。优先适配当前环境里的 js-reverse_* 工具。
---

# MCP 前端 JS 逆向作业规范

## 适用范围

当任务属于以下场景时优先使用本 skill：

- 定位接口签名、加密参数、风控字段
- 观察页面请求链路与脚本来源
- 在运行时抓取函数入参与返回值
- 追踪某个 XHR/Fetch/WebSocket 的触发点
- 把页面证据带回 Node 做本地复现与补环境

如果目标是二进制、APK、PE、ELF、DLL、SO，请改用 `ida-reverse`、`radare2` 或 `reverse-engineering`。

## 当前环境默认工具映射

本 skill 不假设存在裸工具名，而是默认绑定当前 OpenCode 环境里的 `js-reverse_*` 工具。

常用映射：

- `list_scripts` -> `js-reverse_list_scripts`
- `get_script_source` -> `js-reverse_get_script_source`
- `search_in_sources` -> `js-reverse_search_in_sources`
- `break_on_xhr` -> `js-reverse_break_on_xhr`
- `evaluate_script` -> `js-reverse_evaluate_script`
- `get_paused_info` -> `js-reverse_get_paused_info`
- `set_breakpoint_on_text` -> `js-reverse_set_breakpoint_on_text`
- `list_network_requests` -> `js-reverse_list_network_requests`
- `get_request_initiator` -> `js-reverse_get_request_initiator`
- `get_websocket_messages` -> `js-reverse_get_websocket_messages`
- `take_screenshot` -> `js-reverse_take_screenshot`
- `new_page` -> `js-reverse_new_page`
- `navigate_page` -> `js-reverse_navigate_page`
- `select_page` -> `js-reverse_select_page`
- `select_frame` -> `js-reverse_select_frame`
- `pause/resume` -> `js-reverse_pause_or_resume`

如果未来工具名前缀变化，先更新本节，不要在执行时临时猜测。

## 核心原则

- `Observe-first`
- `Hook-preferred`
- `Breakpoint-last`
- `Rebuild-oriented`
- `Evidence-first`

先页面观察，再最小化采样，再做本地补环境，不要跳过取证直接猜环境。

## 五阶段工作流

### 1. Observe

目标：先确认目标请求、相关脚本、候选函数，不猜环境。

默认动作：

- 用 `js-reverse_new_page` 或 `js-reverse_navigate_page` 打开目标页面
- 用 `js-reverse_list_network_requests` 找目标请求
- 用 `js-reverse_get_request_initiator` 回溯调用来源
- 用 `js-reverse_list_scripts`、`js-reverse_search_in_sources` 缩小脚本范围

必须产出：

- 目标请求 URL 或特征
- initiator 线索
- 可疑脚本 URL
- 初始任务记录

### 2. Capture

目标：对目标请求做最小侵入采样，拿到参数样例、调用顺序、运行时证据。

规则：

- 优先 `js-reverse_break_on_xhr`
- 优先 `js-reverse_evaluate_script` 做轻量运行时观察
- 命中后先看 `js-reverse_get_paused_info`
- 必要时再用 `js-reverse_set_breakpoint_on_text`

### 3. Rebuild

目标：把页面证据整理成本地可迭代的 Node 复现材料。

规则：

- 本地补环境必须以页面观测证据为依据
- 不允许空想式补 `window/document/navigator/crypto/storage`
- 每次只记录一个最小因果补丁决策

### 4. Patch

目标：按报错和 first divergence 驱动补环境，直到本地脚本稳定跑出目标参数。

规则：

- 先看缺什么，再补什么
- 一次只做一个最小补丁决策
- 每次补丁后立即复测
- 每次补丁都写入任务记录

### 5. DeepDive

目标：本地跑通后，再做去混淆、控制流还原、业务逻辑提纯。

规则：

- 如果当前任务只是出签名，这一阶段可以降级
- 如果要长期复用算法链路，这一阶段必须做

## 执行要求

- 所有重要步骤都要写入本地 task artifact
- 如果无法解释为什么调用某个工具，就不要调用
- 优先使用 `js-reverse_*` 工具直接取证，不要先写脚本重造能力
- 失败时按 `references/fallbacks.md` 回退
- 输出遵循 `references/output-contract.md`

## 必读引用

- 自动化入口：`references/automation-entry.md`
- 参数默认值：`references/tool-defaults.md`
- 任务输入模板：`references/task-input-template.md`
- MCP 专用任务编排：`references/mcp-task-template.md`
- 任务产物：`references/task-artifacts.md`
- 本地复现：`references/local-rebuild.md`
- 补环境：`references/env-patching.md`
- Node 复现：`references/node-env-rebuild.md`
- 插桩：`references/instrumentation.md`
- AST 去混淆：`references/ast-deobfuscation.md`
- 回退：`references/fallbacks.md`
- 输出契约：`references/output-contract.md`
