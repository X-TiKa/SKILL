#!/usr/bin/env python3
"""
写前准备 - 技能重构3.0版 唯一大脑

读取所有规则文件、配料表、事件池、状态文件，生成 11 段准备报告。
准备报告注入 AI 上下文，确保 AI 在约束空间内创作。

用法:
    python 写前准备.py --book <书名> --chapter <章节号> [--goal <本章目标>] [--state <状态文件路径>]

输出:
    11 段 Markdown 准备报告，写入 stdout
"""

import argparse
import json
import sys
from pathlib import Path
from datetime import datetime

# ── 系统路径 ──────────────────────────────────────────────
SYSTEM_DIR = Path(__file__).parent.parent  # 技能重构3.0版/
RULES_DIR = SYSTEM_DIR
INGREDIENTS_DIR = SYSTEM_DIR / "配料表"
EVENTS_DIR = SYSTEM_DIR / "事件池"

# ── 规则文件清单 ──────────────────────────────────────────
RULE_FILES = [
    "SKILL.md",
    "01-生成式原理.md",
    "02-写前准备.md",
    "03-写作执行.md",
    "04-去AI味.md",
    "05-自检清单.md",
    "06-补写修正.md",
    "07-大纲与节奏.md",
    "08-伏笔与一致性.md",
    "09-续写循环.md",
]

INGREDIENT_FILES = [
    "01-衣着服饰.md",
    "02-身体感官.md",
    "03-动作互动.md",
    "04-叫床声音.md",
    "05-心理关系.md",
    "06-场景设定.md",
    "07-写作技法.md",
]

# ── 固定禁用词 ────────────────────────────────────────────
FIXED_BANNED_WORDS = [
    "不禁", "仿佛", "宛如", "宛若", "映入眼帘",
    "心中暗道", "暗自思忖", "不由得", "一时间",
    "与此同时", "毫无疑问", "事实上", "总的来说",
    "令人印象深刻", "仿佛一切都在",
]


def read_file(path: Path) -> str:
    """读取文件内容，文件不存在则返回空字符串"""
    try:
        return path.read_text(encoding="utf-8")
    except FileNotFoundError:
        return f"[文件不存在: {path}]\n"


def extract_section(content: str, heading: str) -> str:
    """从 Markdown 内容中提取指定标题下的内容"""
    lines = content.split("\n")
    in_section = False
    result = []
    heading_pattern = f"## {heading}"
    for line in lines:
        if line.strip().startswith(heading_pattern):
            in_section = True
            continue
        if in_section and line.strip().startswith("## "):
            break
        if in_section:
            result.append(line)
    return "\n".join(result).strip()


def extract_hard_boundaries(content: str) -> dict:
    """从 SKILL.md 提取硬边界"""
    boundaries = {}
    # 解析硬边界表格
    in_table = False
    for line in content.split("\n"):
        if "硬边界" in line:
            in_table = True
            continue
        if in_table and line.strip().startswith("|"):
            parts = [p.strip() for p in line.split("|") if p.strip()]
            if len(parts) >= 3 and parts[0].isdigit():
                boundaries[parts[1]] = parts[2]
        if in_table and not line.strip().startswith("|"):
            break
    return boundaries


def load_state(state_path: Path | None) -> dict:
    """加载状态文件"""
    if state_path is None:
        return {}
    content = read_file(state_path)
    if not content.strip():
        return {}
    # 简单的状态解析（Markdown 格式）
    state = {"raw": content}
    # 提取章节号
    for line in content.split("\n"):
        if "当前章节" in line:
            state["current_chapter"] = line.split("：")[-1].strip() if "：" in line else ""
        if "总章节数" in line:
            state["total_chapters"] = line.split("：")[-1].strip() if "：" in line else ""
        if "当前卷" in line:
            state["current_arc"] = line.split("：")[-1].strip() if "：" in line else ""
    return state


def generate_section_1_constraints(book_name: str, chapter_num: int,
                                    goal: str, state: dict) -> str:
    """第 1 段：本章约束摘要"""
    # 从状态文件推断类型和节奏
    book_type = "NTR"  # 默认，实际应从状态文件或参数获取
    rhythm = "中档"    # 默认
    word_count = "3000–5000 字"

    # 从状态文件获取禁用词
    banned_words = FIXED_BANNED_WORDS.copy()
    if state.get("raw"):
        # 从状态文件提取已用词
        for line in state["raw"].split("\n"):
            if "已用词" in line:
                extra = [w.strip() for w in line.split("：")[-1].split("、") if w.strip()]
                banned_words.extend(extra)

    lines = [
        "## 第 1 段：本章约束摘要",
        "",
        f"- **书名**：{book_name}",
        f"- **章节**：第 {chapter_num} 章",
        f"- **类型**：{book_type}",
        f"- **目标字数**：{word_count}",
        f"- **节奏档位**：{rhythm}",
        f"- **可用配额**：A/B/C 中可触发 1 项",
        f"- **禁用词**：{', '.join(banned_words[:12])}...",
        f"- **本章目标**：{goal or '（由 AI 根据大纲确定）'}",
        "",
    ]
    return "\n".join(lines)


def generate_section_2_outline(state: dict, chapter_num: int) -> str:
    """第 2 段：大纲锚点"""
    current_arc = state.get("current_arc", "（未设定）")
    total_chapters = state.get("total_chapters", "（未设定）")
    progress = f"{chapter_num}/{total_chapters}" if total_chapters != "（未设定）" else "（未设定）"

    lines = [
        "## 第 2 段：大纲锚点",
        "",
        f"- **当前卷**：{current_arc}",
        f"- **当前章节**：第 {chapter_num} 章 / 共 {total_chapters} 章",
        f"- **进度**：{progress}",
        f"- **本章必须推进**：≥2 个事件，≥1 个非内心独白",
        f"- **本章不得超越**：（由 AI 根据大纲确定）",
        "",
    ]
    return "\n".join(lines)


def generate_section_3_characters(state: dict) -> str:
    """第 3 段：角色状态"""
    lines = [
        "## 第 3 段：角色状态",
        "",
        "（从状态文件恢复，或由 AI 根据本章设定）",
        "",
        "- **视角角色**：（确定）",
        "- **在场角色**：（确定）",
        "- **各角色情绪/位置/关系**：（从状态文件恢复）",
        "- **本章称呼规则**：见配料表 `04-叫床声音.md` 第六节",
        "",
    ]
    return "\n".join(lines)


def generate_section_4_dialogue() -> str:
    """第 4 段：对话配额"""
    lines = [
        "## 第 4 段：对话配额",
        "",
        "- **目标对话占比**：40–65%（肉戏章偏低30–50%，对话章偏高60–80%）",
        "- **本章目标对话字数**：≥1200 字（按 3000 字章计算，40%）",
        "- **角色声音区分**：",
        "  - 词汇选择：每个角色不同",
        "  - 句子长度：主角 5–20 字，配角 3–15 字",
        "  - 语气词：每个角色不同",
        "  - 称呼习惯：每个角色不同",
        "- **对话节奏**：短句交锋（3–8字）× 3–5轮 → 中句（10–20字）× 1–2轮 → 短句交锋",
        "",
    ]
    return "\n".join(lines)


def generate_section_5_sex() -> str:
    """第 5 段：肉戏配额"""
    lines = [
        "## 第 5 段：肉戏配额",
        "",
        "- **肉戏比重目标**：有肉戏的章节≥40%（不是每章都必须有肉戏，无肉戏的章节比重为0%是正常的）",
        "- **本章目标肉戏字数**：≥1200 字（按 3000 字章计算）",
        "- **配菜上限**：≤1.5 × 肉戏字数 = ≤1800 字",
        "- **感官分布**：触觉≥40%, 听觉≥20%, 视觉≤30%, 味觉/嗅觉≥10%",
        "- **肉戏结构**：前戏 → 进入 → 呻吟段1 → 喘息过渡 → 呻吟段2 → 体位变化 → 呻吟段3 → 高潮 → 余韵",
        "- **呻吟密度**：每个肉戏段 ≥ 3 处有声呻吟（带引号）",
        "- **体位变化**：每个肉戏段 ≥ 1 次",
        "- **纯爱 vs 非纯爱**：纯爱肉戏侧重情感交融、温柔渐进；非纯爱肉戏侧重刺激多变、体位丰富",
        "",
    ]
    return "\n".join(lines)


def generate_section_6_ingredients() -> str:
    """第 6 段：配料表（从配料表文件读取摘要）"""
    lines = [
        "## 第 6 段：配料表",
        "",
        "（从以下配料表文件中按需选取词条，详见各配料表文件）",
        "",
    ]
    for f in INGREDIENT_FILES:
        filepath = INGREDIENTS_DIR / f
        if filepath.exists():
            # 读取文件标题
            first_line = ""
            try:
                for line in filepath.read_text(encoding="utf-8").split("\n"):
                    if line.startswith("# "):
                        first_line = line[2:].strip()
                        break
            except Exception:
                pass
            lines.append(f"- **{f}**：{first_line}")
    lines.append("")
    lines.append("**使用规则**：配料表是参考，不是牢笼。AI 在配料表提供的方向内自由生成，不机械照搬词条。")
    lines.append("")
    return "\n".join(lines)


def generate_section_7_events() -> str:
    """第 7 段：事件池"""
    event_file = EVENTS_DIR / "事件池.md"
    lines = [
        "## 第 7 段：事件池",
        "",
        "（从事件池中按需选取事件，默认为 1–3 个，根据章节节奏灵活调整。池中无匹配时，按事件池中的「事件扩展规则」自行生成新事件，详见 `事件池/事件池.md`）",
        "",
        "- **事件选取规则**：",
        "  - 每章 1–3 个事件",
        "  - 禁止连续两章使用同一子类",
        "  - 事件冷却：同类事件间隔 ≥ 2 章",
        "  - 每个事件落地四拍：触发 → 动作 → 风险痕迹 → 心理变化",
        "",
    ]
    if event_file.exists():
        # 提取事件类别列表
        for line in event_file.read_text(encoding="utf-8").split("\n"):
            if line.startswith("## ") and "类" in line:
                category = line[3:].strip()
                lines.append(f"- {category}")
    lines.append("")
    return "\n".join(lines)


def generate_section_8_focus() -> str:
    """第 8 段：聚焦预设"""
    lines = [
        "## 第 8 段：聚焦预设",
        "",
        "- **聚焦公式**：描写密度 = 1 / 出现频率",
        "- **第一次出现**：详细描写（50–100 字）",
        "- **第二次出现**：中等描写（20–50 字）",
        "- **第三次及以后**：轻描淡写（≤20 字）或完全省略",
        "- **场景空间**：每个场景明确 地点/时间/在场人物/视角角色",
        "- **衣物描写节奏**：脱衣时描写，穿衣时不描写（除非有特殊意义）",
        "",
    ]
    return "\n".join(lines)


def generate_section_9_foreshadowing(state: dict) -> str:
    """第 9 段：伏笔状态"""
    lines = [
        "## 第 9 段：伏笔状态",
        "",
        "（从状态文件恢复伏笔状态）",
        "",
        "- **已埋设伏笔**：从状态文件读取",
        "- **本章可回收伏笔**：从状态文件筛选",
        "- **本章需新埋伏笔**：≥1 个",
        "",
    ]
    # 从状态文件提取伏笔信息
    if state.get("raw"):
        in_foreshadowing = False
        for line in state["raw"].split("\n"):
            if "伏笔追踪" in line:
                in_foreshadowing = True
                continue
            if in_foreshadowing and line.strip().startswith("## "):
                break
            if in_foreshadowing and line.strip():
                lines.append(line)
    lines.append("")
    return "\n".join(lines)


def generate_section_10_anti_ai() -> str:
    """第 10 段：去 AI 味预设"""
    lines = [
        "## 第 10 段：去 AI 味预设",
        "",
        "### 禁用词",
        f"- 固定禁用词（12 个）：{', '.join(FIXED_BANNED_WORDS)}",
        "- 已用词自动禁用：从状态文件读取",
        "",
        "### 禁用句式",
        "- 过度对比：不是 A 而是 B（只用一次或不用）",
        "- 过度排比：从 A 到 B，从 B 到 C",
        "- 过度并列：既……又……不仅……而且……",
        "- 工整句式：要么……要么……要么……",
        "- 前者后者：禁用",
        "",
        "### 句子约束",
        "- 单句 ≤ 30 字",
        "- 段落 3–5 行（手机屏幕）",
        "- 长短句交替",
        "",
        "### 视角约束",
        "- 第一人称叙述者（当前视角角色）",
        "- 有态度、有盲区、有情绪",
        "- 禁上帝视角、禁全知叙述",
        "",
        "### 五破解检查",
        "1. 写画面，不写形容词",
        "2. 写身体反应，不替读者下判断",
        "3. 内心独白禁重",
        "4. 第一人称视角",
        "5. 叙述者是人",
        "",
    ]
    return "\n".join(lines)


def generate_section_11_checklist() -> str:
    """第 11 段：自检预设"""
    lines = [
        "## 第 11 段：自检预设",
        "",
        "写完后必须逐项检查 `05-自检清单.md`（34 项）：",
        "",
        "### 写中快速自查（5 项）",
        "1. 对话占比在合理范围？（40–65%，肉戏章30–50%，对话章60–80%）",
        "2. 有禁用词吗？（搜索 12 个固定禁用词）",
        "3. 有 AI 套话吗？（搜索删除清单）",
        "4. 句长超标吗？（> 30 字的句子）",
        "5. 内心独白 ≤ 30%？",
        "",
        "### 门禁标准",
        "- 34 项全部通过 → 门禁通过",
        "- 有未通过项 → 修正，最多 3 轮",
        "- 3 轮后仍未通过 → 暂停，请求人工介入",
        "",
    ]
    return "\n".join(lines)


def generate_report(
    book_name: str,
    chapter_num: int,
    goal: str = "",
    state_path: Path | None = None,
) -> str:
    """生成完整的 11 段准备报告"""

    # 加载状态
    state = load_state(state_path)

    # 生成报告头部
    report = [
        f"# 写前准备报告",
        f"",
        f"> 自动生成于 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"> 系统版本：技能重构3.0版",
        f"> 单一真源：本报告是 AI 创作本章的唯一约束来源",
        f"",
        "---",
        "",
    ]

    # 生成 11 段
    report.append(generate_section_1_constraints(book_name, chapter_num, goal, state))
    report.append("---\n")
    report.append(generate_section_2_outline(state, chapter_num))
    report.append("---\n")
    report.append(generate_section_3_characters(state))
    report.append("---\n")
    report.append(generate_section_4_dialogue())
    report.append("---\n")
    report.append(generate_section_5_sex())
    report.append("---\n")
    report.append(generate_section_6_ingredients())
    report.append("---\n")
    report.append(generate_section_7_events())
    report.append("---\n")
    report.append(generate_section_8_focus())
    report.append("---\n")
    report.append(generate_section_9_foreshadowing(state))
    report.append("---\n")
    report.append(generate_section_10_anti_ai())
    report.append("---\n")
    report.append(generate_section_11_checklist())

    # 报告尾部
    report.append("---\n")
    report.append("*本报告由写前准备.py 自动生成。规则文件是唯一真源，脚本是机械实现。*\n")

    return "\n".join(report)


def main():
    parser = argparse.ArgumentParser(
        description="写前准备 - 技能重构3.0版 唯一大脑",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
    python 写前准备.py --book "我的小说" --chapter 5 --goal "女主第一次出轨"
    python 写前准备.py --book "我的小说" --chapter 6 --state ../状态文件.md
        """,
    )
    parser.add_argument("--book", required=True, help="书名")
    parser.add_argument("--chapter", type=int, required=True, help="章节号")
    parser.add_argument("--goal", default="", help="本章写作目标（剧情方向）")
    parser.add_argument("--state", type=Path, default=None, help="状态文件路径（续写时使用）")
    parser.add_argument("--output", type=Path, default=None, help="输出文件路径（默认 stdout）")

    args = parser.parse_args()

    report = generate_report(
        book_name=args.book,
        chapter_num=args.chapter,
        goal=args.goal,
        state_path=args.state,
    )

    if args.output:
        args.output.write_text(report, encoding="utf-8")
        print(f"准备报告已写入: {args.output}", file=sys.stderr)
    else:
        print(report)


if __name__ == "__main__":
    main()